import * as ServiceWorker from './core/ServiceWorker';

ServiceWorker.setup();
